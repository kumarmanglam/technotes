`npm i nodemon -g`


- -g means install globally


